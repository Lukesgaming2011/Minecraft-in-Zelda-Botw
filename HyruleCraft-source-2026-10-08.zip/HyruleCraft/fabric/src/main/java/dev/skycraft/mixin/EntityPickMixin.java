package dev.skycraft.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import dev.skycraft.world.SkyClip;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

/**
 * The crosshair targets Skyrim surfaces: blocks can be placed on terrain and walls, and NPCs behind a
 * wall can't be hit through it. A Skyrim hit points at the cell a placed block would occupy.
 */
@Mixin(Entity.class)
public abstract class EntityPickMixin {
    private static int hyrulecraft$pickOriginLogs;
    @WrapOperation(method = "pick", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/Entity;getEyePosition(F)Lnet/minecraft/world/phys/Vec3;"))
    private net.minecraft.world.phys.Vec3 hyrulecraft$nativePickOrigin(Entity entity, float partialTick, Operation<net.minecraft.world.phys.Vec3> original) {
        var vanilla=original.call(entity,partialTick);
        if (!entity.level().isClientSide() || !(entity instanceof net.minecraft.world.entity.player.Player)) return vanilla;
        var nativeEye=dev.skycraft.link.NativePickOrigin.read(dev.skycraft.link.SkyLink.segment(),dev.skycraft.link.SkyLink.tickCount(),vanilla);
        if (Boolean.getBoolean("hyrulecraft.demo") && nativeEye != vanilla && hyrulecraft$pickOriginLogs++ < 3) dev.skycraft.SkyCraft.LOG.info("HyruleCraft: actual pick native eye {} vanilla {}",nativeEye,vanilla);
        return nativeEye;
    }

	@WrapOperation(
		method = "pick",
		at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/Level;clip(Lnet/minecraft/world/level/ClipContext;)Lnet/minecraft/world/phys/BlockHitResult;")
	)
	private BlockHitResult skycraft$pickSkyrim(Level level, ClipContext context, Operation<BlockHitResult> original) {
		return SkyClip.refine(context.getFrom(), context.getTo(), original.call(level, context), SkyClip.Use.PICK);
	}
}
