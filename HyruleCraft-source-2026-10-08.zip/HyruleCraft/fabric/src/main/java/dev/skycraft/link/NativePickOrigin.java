package dev.skycraft.link;

import java.lang.foreign.MemorySegment;
import java.lang.invoke.VarHandle;
import static java.lang.foreign.ValueLayout.*;
import net.minecraft.world.phys.Vec3;

/** First-person block picking starts at the same native eye used by the compositor. */
public final class NativePickOrigin {
    private static final VarHandle INT = JAVA_INT.varHandle();
    private static final VarHandle LONG = JAVA_LONG.varHandle();
    private NativePickOrigin() {}
    public static Vec3 read(MemorySegment memory, long now, Vec3 vanilla) {
        if (memory == null || memory.byteSize() < 0xc40) return vanilla;
        if (memory.get(JAVA_INT,0) != Proto.MAGIC || memory.get(JAVA_INT,4) != Proto.VERSION) return vanilla;
        long age=now-(long)LONG.getAcquire(memory,0x10L);
        if (age<0 || age>500 || memory.get(JAVA_INT,0x2c0)!=0) return vanilla;
        int flags=memory.get(JAVA_INT,0x204);
        if ((flags&Proto.MC_IN_WORLD)==0 || (flags&(Proto.MC_SCREEN_OPEN|Proto.MC_DEAD))!=0) return vanilla;
        for (int attempt=0;attempt<3;attempt++) {
            int seq=(int)INT.getAcquire(memory,0xc00L);
            if (seq==0 || (seq&1)!=0) continue;
            int tag=memory.get(JAVA_INT,0xc04);
            Vec3 eye=new Vec3(memory.get(JAVA_DOUBLE,0xc08),memory.get(JAVA_DOUBLE,0xc10),memory.get(JAVA_DOUBLE,0xc18));
            VarHandle.acquireFence();
            if (seq!=(int)INT.getAcquire(memory,0xc00L)) continue;
            if (tag!=0x41434348 || !Double.isFinite(eye.x) || !Double.isFinite(eye.y) || !Double.isFinite(eye.z)) return vanilla;
            // Refuse event/third-person cameras; keep interaction reach near the player.
            return eye.distanceToSqr(vanilla)<=0.25 ? eye : vanilla;
        }
        return vanilla;
    }
}
