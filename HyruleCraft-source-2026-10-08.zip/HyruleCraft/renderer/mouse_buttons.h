// MIT, HyruleCraft. Reliable held buttons and short click pulses.
#pragma once
#include <cstdint>
namespace hyrulecraft {
class MouseButtons {
    bool held_[3]{},pending_[3]{};
public:
    void reset(){for(int i=0;i<3;++i)held_[i]=pending_[i]=false;}
    template<class Emit> void update(uint32_t snapshot,Emit&& emit){
        constexpr uint16_t codes[]={1,3,2}; // SDL left/right/middle
        for(int i=0;i<3;++i){
            bool down=(snapshot&(1u<<i))!=0;
            pending_[i]=pending_[i] || (snapshot&(1u<<(i+8)));
            if(held_[i]&&!down){
                if(!emit(codes[i],false))continue;
                held_[i]=false;
            }
            if(down){
                if(!held_[i]){if(!emit(codes[i],true))continue;held_[i]=true;}
                pending_[i]=false;
            }else if(pending_[i]&&!held_[i]){
                if(!emit(codes[i],true))continue;
                held_[i]=true;pending_[i]=false;
                // If the ring fills here, held_ retains the required release
                // for the next frame instead of leaving Minecraft mining.
                if(emit(codes[i],false))held_[i]=false;
            }
        }
    }
};
}
