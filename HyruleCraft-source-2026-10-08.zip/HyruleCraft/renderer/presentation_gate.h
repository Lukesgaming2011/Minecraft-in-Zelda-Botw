#pragma once
#include <cstdint>
namespace hyrulecraft {
// Gate only the initial reveal. Streaming frontiers must not flash the scene.
class PresentationGate {
    bool visible_ = false, waiting_ = false;
    uint64_t since_ = 0;
public:
    void reset() { visible_ = waiting_ = false; since_ = 0; }
    bool retainDuringPause(uint64_t now, uint64_t hostBeat, uint64_t mcBeat) const {
        return visible_ && hostBeat && mcBeat && now >= hostBeat && now >= mcBeat
            && now - hostBeat <= 1500 && now - mcBeat <= 1500;
    }
    bool update(uint64_t now, bool ready) {
        if (visible_) return true;
        if (!ready) { waiting_ = false; return false; }
        if (!waiting_ || now < since_) { waiting_ = true; since_ = now; }
        if (now - since_ >= 750) visible_ = true;
        return visible_;
    }
};
}
