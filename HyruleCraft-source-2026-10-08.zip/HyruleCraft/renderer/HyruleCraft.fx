// HyruleCraft compositing: Minecraft world depth is camera-forward metres.
texture HCWorld : HCWORLD;
texture HCDistance : HCDEPTH;
texture HCOverlay : HCOVERLAY;
texture HostDepth : DEPTH;
texture HostColor : COLOR;
sampler WorldSampler { Texture = HCWorld; };
sampler DistanceSampler { Texture = HCDistance; MinFilter = POINT; MagFilter = POINT; };
sampler OverlaySampler { Texture = HCOverlay; };
sampler DepthSampler { Texture = HostDepth; MinFilter = POINT; MagFilter = POINT; };
sampler ColorSampler { Texture = HostColor; };
uniform bool HyruleActive = false;
uniform bool DepthAvailable < source = "bufready_depth"; > = false;
uniform float SceneScaleY = 1.0;
uniform bool ApplySceneScaleY < ui_label = "Apply SceneScaleY stretching to depth"; > = false;
uniform bool OverlayBottomUp = true;
uniform bool HostDepthReversed < ui_label = "BOTW reversed depth"; > = false;
uniform bool HostDepthFlipped < ui_label = "BOTW depth upside-down"; > = false;
uniform bool UseHostDepth < ui_label = "Occlude Minecraft with BOTW depth"; > = true;
uniform float HostDepthBias < ui_label = "Base depth bias (metres)"; ui_min = 0.0; ui_max = 0.5; > = 0.05;
// Screen-derived ambient colour is an approximation: it does not import BOTW
// sun/shadow maps. Sample native colour before MC and keep the HUD untouched.
uniform bool MatchSceneLighting < ui_label = "Match native scene ambient lighting"; > = true;
uniform float SceneLightingStrength < ui_min = 0.0; ui_max = 1.0; > = 0.9;
uniform bool MatchSceneFog < ui_label = "Blend distant blocks with native atmosphere"; > = true;
uniform float HostNear < ui_label = "BOTW near plane"; > = 0.1;
uniform float HostFar < ui_label = "BOTW far plane"; > = 25000.0;
void FullscreenVS(uint id : SV_VertexID, out float4 p : SV_Position, out float2 uv : TEXCOORD) {
    uv = float2((id << 1) & 2, id & 2);
    p = float4(uv * float2(2,-2) + float2(-1,1), 0,1);
}
float HostDistance(float2 uv) {
    if (ApplySceneScaleY) uv.y = (uv.y - 0.5) * SceneScaleY + 0.5;
    if (HostDepthFlipped) uv.y = 1.0 - uv.y;
    float d = tex2D(DepthSampler, uv).r;
    if (HostDepthReversed) d = 1.0 - d;
    return HostNear * HostFar / max(HostFar - d * (HostFar - HostNear), 0.0001);
}
float3 SceneIllumination() {
    float3 ambient = (tex2D(ColorSampler,float2(.2,.35)).rgb
        +tex2D(ColorSampler,float2(.8,.35)).rgb
        +tex2D(ColorSampler,float2(.2,.65)).rgb
        +tex2D(ColorSampler,float2(.8,.65)).rgb)*.25;
    float luminance = dot(ambient,float3(.2126,.7152,.0722));
    float brightness = clamp(sqrt(max(luminance,0.0))*1.2,.16,1.0);
    float3 tint = clamp(ambient/max(luminance,.02),.7,1.3);
    return lerp(float3(1,1,1),brightness*lerp(float3(1,1,1),tint,.25),SceneLightingStrength);
}
float4 CompositePS(float4 p:SV_Position,float2 uv:TEXCOORD):SV_Target {
    float4 bg = tex2D(ColorSampler,uv);
    if (!HyruleActive) return bg;
    // Native mesh projection uses a left-pointing horizontal basis; undo that
    // reflection here so world geometry remains anchored as the camera turns.
    float2 worldUV = float2(1-uv.x,1-uv.y);
    float4 mc = tex2D(WorldSampler,worldUV);
    float distance = tex2D(DistanceSampler,worldUV).r;
    // Derivatives must execute outside the pixel-varying Minecraft coverage branch.
    float zh = HostDistance(uv);
    float slope = max(abs(ddx(zh)), abs(ddy(zh)));
    if (mc.a > 0 && distance > 0) {
        float bias = HostDepthBias + clamp(slope * 0.5, 0.0, 0.2);
        if (!UseHostDepth || !DepthAvailable || distance <= zh + bias) {
            float3 lit = mc.rgb*(MatchSceneLighting ? SceneIllumination() : float3(1,1,1));
            // Atmospheric approximation from native horizon colour; no shadow-map claim.
            float3 haze=(tex2D(ColorSampler,float2(.15,.35)).rgb+tex2D(ColorSampler,float2(.85,.35)).rgb)*.5;
            float fog = MatchSceneFog ? 1-exp(-max(distance-12,0)*.009) : 0;
            lit=lerp(lit,haze*mc.a,fog);
            float fade=1-smoothstep(72,96,distance);
            bg.rgb = lit*fade + bg.rgb*(1-mc.a*fade);
        }
    }
    float2 overlayUV = float2(uv.x, OverlayBottomUp ? 1-uv.y : uv.y);
    float4 hud = tex2D(OverlaySampler,overlayUV);
    bg.rgb = hud.rgb + bg.rgb*(1-hud.a);
    return float4(bg.rgb,1);
}
technique HyruleCraft {
    pass { VertexShader = FullscreenVS; PixelShader = CompositePS; }
}
