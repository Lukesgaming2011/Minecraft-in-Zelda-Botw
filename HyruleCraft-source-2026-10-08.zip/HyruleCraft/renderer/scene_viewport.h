#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
namespace hyrulecraft {
struct SceneViewport { uint32_t x,y,width,height; };
inline SceneViewport sceneViewport(uint32_t w,uint32_t h,float aspect) {
 if(!std::isfinite(aspect)||aspect<.5f||aspect>4.f)aspect=16.f/9.f;
 if(!w||!h)return {0,0,0,0};
 uint32_t sw=w,sh=h;
 if(double(w)/h>aspect)sw=std::max(1u,std::min(w,uint32_t(std::lround(double(h)*aspect))));
 else sh=std::max(1u,std::min(h,uint32_t(std::lround(double(w)/aspect))));
 return {(w-sw)/2,(h-sh)/2,sw,sh};
}
}
