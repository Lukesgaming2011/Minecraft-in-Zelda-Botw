package dev.skycraft.world;
import static org.junit.jupiter.api.Assertions.*;
import java.lang.foreign.MemorySegment;
import java.lang.reflect.*;
import java.util.*;
import net.minecraft.world.phys.AABB;
import org.junit.jupiter.api.*;
class SkyCollisionStreamingTest {
 static Field field(String name)throws Exception {var f=SkyCollision.class.getDeclaredField(name);f.setAccessible(true);return f;}
 static Method method(String name,Class<?>... types)throws Exception {var m=SkyCollision.class.getDeclaredMethod(name,types);m.setAccessible(true);return m;}
 static long key(int x,int y,int z)throws Exception {return (long)method("regionKey",int.class,int.class,int.class).invoke(null,x,y,z);}
 @SuppressWarnings("unchecked") static Set<Long> known()throws Exception {return (Set<Long>)field("KNOWN_REGIONS").get(null);}
 @BeforeEach void reset()throws Exception {known().clear();field("epoch").setInt(null,7);}
 @Test void sweptBoxCannotCrossAnUnknownRegion()throws Exception {known().add(key(0,0,0));assertTrue(SkyCollision.covers(new AABB(1,1,1,2,2,2)));assertFalse(SkyCollision.covers(new AABB(1,1,1,9,2,2)));known().add(key(1,0,0));assertTrue(SkyCollision.covers(new AABB(1,1,1,9,2,2)));}
 @Test void negativeCoordinatesUseFloorRegions()throws Exception {known().add(key(-1,0,-1));assertTrue(SkyCollision.covers(new AABB(-7,1,-7,-1,2,-1)));assertFalse(SkyCollision.covers(new AABB(-9,1,-7,-1,2,-1)));}
 @Test void excessiveOrNonfiniteSweepFailsClosed()throws Exception {assertFalse(SkyCollision.covers(new AABB(-1e20,0,0,1e20,1,1)));assertFalse(SkyCollision.covers(new AABB(0,0,0,Double.POSITIVE_INFINITY,1,1)));}
 @Test void evictionOnlyRemovesTheNamedRegion()throws Exception {known().add(key(100,0,0));known().add(key(0,0,0));method("forgetRegion",MemorySegment.class,long.class).invoke(null,MemorySegment.ofArray(new int[]{100,0,0,7}),0L);assertFalse(known().contains(key(100,0,0)));assertTrue(known().contains(key(0,0,0)));}
 @Test void staleEvictionCannotDeleteANewEpoch()throws Exception {known().add(key(100,0,0));method("forgetRegion",MemorySegment.class,long.class).invoke(null,MemorySegment.ofArray(new int[]{100,0,0,6}),0L);assertTrue(known().contains(key(100,0,0)));}
}
