package dev.skycraft.client;

import dev.skycraft.link.SkyLink;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Blocks;

/** Opt-in real-server block fixture for testing the Cemu compositor. */
public final class HyruleDev {
    private static BlockPos clicked;
    private static int clickTicks;
    public static void observeGroundClick(Minecraft mc) {
        if (!Boolean.getBoolean("hyrulecraft.demo") || !(mc.hitResult instanceof dev.skycraft.world.SkyClip.SkyrimHitResult hit) || mc.level == null) return;
        clicked = hit.getBlockPos().immutable();clickTicks=0;
        dev.skycraft.SkyCraft.LOG.info("HyruleCraft: terrain click cell {} before {} hit {}",clicked,mc.level.getBlockState(clicked),hit.getLocation());
    }
    private static boolean placed;
    private static int readyTicks;
    private static int generation = -1;
    public static void tick(Minecraft mc) {
        if (clicked != null && ++clickTicks>=10 && mc.getSingleplayerServer()!=null) {
            BlockPos cell=clicked;clicked=null;
            var server=mc.getSingleplayerServer();
            server.execute(() -> dev.skycraft.SkyCraft.LOG.info("HyruleCraft: terrain click server result {} -> {}",cell,server.overworld().getBlockState(cell)));
        }
        if (generation != SkyLink.generation()) {
            generation = SkyLink.generation();
            placed = false;
            readyTicks = 0;
        }
        int fixtureMode=SkyLink.devFixtureMode();
        if (!Boolean.getBoolean("hyrulecraft.demo") || placed || fixtureMode==0 || !SkyLink.active() || !SkyClient.terrainReady() || mc.player == null || mc.getSingleplayerServer() == null) return;
        if (++readyTicks < 40) return; // Let the native look and server teleport settle.
        var p = mc.player;
        double yaw = Math.toRadians(p.getYRot());
        int[] requested=SkyLink.devExistingTarget(fixtureMode);
        if (fixtureMode==3 && requested==null) return;
        BlockPos pos = requested==null ? BlockPos.containing(p.getX()-Math.sin(yaw)*3, p.getY(), p.getZ()+Math.cos(yaw)*3) : new BlockPos(requested[0],requested[1],requested[2]);
        if (new net.minecraft.world.phys.Vec3(pos.getX()+.5,pos.getY()+.5,pos.getZ()+.5).distanceTo(p.position())>4.5) return;
        var server = mc.getSingleplayerServer();
        placed = true;
        int fixtureGeneration = generation;
        server.execute(() -> {
            if (requested==null) server.overworld().setBlock(pos, Blocks.OAK_PLANKS.defaultBlockState(), 3);
            if (server.overworld().getBlockState(pos).is(Blocks.OAK_PLANKS)) {
                SkyLink.publishDevFixture(fixtureGeneration, pos.getX(), pos.getY(), pos.getZ());
            }
            dev.skycraft.SkyCraft.LOG.info("HyruleCraft: server movement target {} existing={} state={}",pos,requested!=null,server.overworld().getBlockState(pos));
        });
    }
}

