import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from runtime_config import native_directory
NATIVE=native_directory(ROOT)
sys.path.insert(0,str(NATIVE))
