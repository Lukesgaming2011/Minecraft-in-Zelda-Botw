package dev.skycraft.world;
/** Stops runaway host/player separation while allowing movement back toward the host. */
public final class TrackingGuard {
 private TrackingGuard() {}
 public static boolean allows(double x,double y,double z,double dx,double dy,double dz,double hx,double hy,double hz) {
  double[] v={x,y,z,dx,dy,dz,hx,hy,hz};
  for(double n:v)if(!Double.isFinite(n)||Math.abs(n)>20032)return false;
  double oldHorizontal=Math.hypot(x-hx,z-hz),nextHorizontal=Math.hypot(x+dx-hx,z+dz-hz);
  double oldVertical=Math.abs(y-hy),nextVertical=Math.abs(y+dy-hy);
  if(nextHorizontal>2 && nextHorizontal>oldHorizontal+1e-6)return false;
  if(nextVertical>6 && nextVertical>oldVertical+1e-6)return false;
  return true;
 }
}
