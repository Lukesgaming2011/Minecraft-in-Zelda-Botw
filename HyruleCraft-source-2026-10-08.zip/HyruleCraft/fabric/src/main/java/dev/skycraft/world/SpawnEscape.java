package dev.skycraft.world;
import java.util.function.DoublePredicate;
/** Bounded upward spawn recovery, using the actual player collision box. */
public final class SpawnEscape {
    private SpawnEscape() {}
    public static double rise(double minimum, DoublePredicate free) {
        if (!Double.isFinite(minimum) || minimum < 0 || minimum > 4) return Double.NaN;
        if (free.test(minimum)) return minimum;
        for (int i=(int)Math.floor(minimum*16)+1;i<=64;i++) {
            double dy=i/16.0;
            if (free.test(dy)) return dy;
        }
        return Double.NaN;
    }
}
