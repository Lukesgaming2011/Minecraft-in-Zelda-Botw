// MIT, HyruleCraft. Windows polling is permitted only after the caller's input lease.
#pragma once
#include <windows.h>
#include <cstdint>
#include <cstring>
#include <utility>
#include <initializer_list>
#include <deque>

namespace hyrulecraft {
// SDL uses physical USB scancodes. Resolve Windows' layout-dependent VK first,
// otherwise AZERTY's VK_A, for example, incorrectly becomes the physical A key.
inline int scanToSdl(unsigned scan) {
    if (scan & 0x100) {
        switch (scan & 0xff) {
        case 0x1c:return 88; case 0x1d:return 228; case 0x35:return 84;
        case 0x37:return 70; case 0x38:return 230; case 0x47:return 74;
        case 0x48:return 82; case 0x49:return 75; case 0x4b:return 80;
        case 0x4d:return 79; case 0x4f:return 77; case 0x50:return 81;
        case 0x51:return 78; case 0x52:return 73; case 0x53:return 76;
        case 0x5b:return 227; case 0x5c:return 231; case 0x5d:return 101;
        default:return 0;
        }
    }
    // Set-1 scan position -> SDL scancode, including ISO extra key (0x56).
    static constexpr unsigned char set1[] = {
        0,41,30,31,32,33,34,35,36,37,38,39,45,46,42,43,
        20,26,8,21,23,28,24,12,18,19,47,48,40,224,4,22,
        7,9,10,11,13,14,15,51,52,53,225,49,29,27,6,25,
        5,17,16,54,55,56,229,85,226,44,57,58,59,60,61,62,
        63,64,65,66,67,83,71,95,96,97,86,92,93,94,87,89,
        90,91,98,99,0,0,100,68,69
    };
    return scan < sizeof(set1) ? set1[scan] : 0;
}
inline int vkToSdl(int vk, HKL layout) {
    // Navigation keys need their extended identities; Windows may omit E0 in
    // MapVirtualKey for NUMLOCK-dependent aliases. F13-F24 have no Set-1 row.
    if(vk>=VK_F1 && vk<=VK_F12)return 58+vk-VK_F1;
    if(vk>=VK_F13 && vk<=VK_F24)return 104+vk-VK_F13;
    if(vk>=VK_NUMPAD1 && vk<=VK_NUMPAD9)return 89+vk-VK_NUMPAD1;
    switch(vk){
    case VK_NUMPAD0:return 98; case VK_DECIMAL:return 99;
    case VK_DIVIDE:return 84;case VK_MULTIPLY:return 85;
    case VK_SUBTRACT:return 86;case VK_ADD:return 87;
    case VK_SEPARATOR:return 133;
    case VK_INSERT:return 73;case VK_HOME:return 74;case VK_PRIOR:return 75;
    case VK_DELETE:return 76;case VK_END:return 77;case VK_NEXT:return 78;
    case VK_RIGHT:return 79;case VK_LEFT:return 80;case VK_DOWN:return 81;
    case VK_UP:return 82;case VK_PAUSE:return 72;case VK_SNAPSHOT:return 70;
    case VK_NUMLOCK:return 83;case VK_SCROLL:return 71;
    case VK_LSHIFT:return 225;case VK_RSHIFT:return 229;
    case VK_LCONTROL:return 224;case VK_RCONTROL:return 228;
    case VK_LMENU:return 226;case VK_RMENU:return 230;
    case VK_LWIN:return 227;case VK_RWIN:return 231;case VK_APPS:return 101;
    case VK_SLEEP:return 282;
    case VK_VOLUME_UP:return 128;case VK_VOLUME_DOWN:return 129;case VK_VOLUME_MUTE:return 127;
    default:return scanToSdl(MapVirtualKeyExW(vk,MAPVK_VK_TO_VSC_EX,layout));
    }
}
inline bool menuRepeats(int vk) {
    return (vk>='0'&&vk<='Z') || vk==VK_SPACE || vk==VK_BACK || vk==VK_DELETE ||
        vk==VK_LEFT || vk==VK_RIGHT || vk==VK_UP || vk==VK_DOWN ||
        vk==VK_HOME || vk==VK_END || vk==VK_PRIOR || vk==VK_NEXT ||
        (vk>=VK_NUMPAD0&&vk<=VK_DIVIDE) ||
        (vk>=VK_OEM_1&&vk<=VK_OEM_3) || (vk>=VK_OEM_4&&vk<=VK_OEM_8) || vk==VK_OEM_102;
}
// Reject unpaired UTF-16 surrogates and controls, which are IN_KEY actions.
// Return false immediately when the ring is full instead of spinning in render.
template<class Emit> inline bool emitUtf16(const WCHAR* value,int length,Emit&& emit) {
    for(int i=0;i<length;++i){
        uint32_t cp=value[i];
        if(cp>=0xd800&&cp<=0xdbff){
            if(i+1>=length || value[i+1]<0xdc00 || value[i+1]>0xdfff)continue;
            cp=0x10000+((cp-0xd800)<<10)+(value[++i]-0xdc00);
        }else if(cp>=0xdc00&&cp<=0xdfff)continue;
        if(cp>=32 && cp!=127 && !emit(5,0,static_cast<int>(cp),0,0))return false;
    }
    return true;
}
class KeyboardInput {
    std::deque<int> pendingText_;
    bool held_[256]{};
    int activeScan_[256]{};
    uint64_t repeatAt_[256]{};
    WCHAR dead_=0;
    HKL layout_=nullptr;
    bool menu_=false;
    unsigned repeatDelay_=500,repeatInterval_=33;
    static WCHAR combining(WCHAR spacing) {
        switch(spacing){case L'`':return 0x0300;case L'\'':case 0x00b4:return 0x0301;
        case L'^':return 0x0302;case L'~':return 0x0303;case L'"':case 0x00a8:return 0x0308;
        case 0x00b0:return 0x030a;case 0x00b8:return 0x0327;default:return 0;}
    }
    template<class Emit> void text(int vk,const BYTE* state,HKL layout,Emit&& dispatch){
        auto emit=[&](uint16_t,uint16_t,int cp,int,int){
            if(pendingText_.size()>=1024)return false;
            pendingText_.push_back(cp);return true;
        };
        // Ctrl/Alt shortcuts produce no chat characters. AltGr appears as
        // right Alt + left Ctrl and is required by international layouts.
        const bool ctrl=state[VK_CONTROL]&0x80,alt=state[VK_MENU]&0x80;
        const bool altGr=(state[VK_RMENU]&0x80) && !(state[VK_LMENU]&0x80) && !(state[VK_RCONTROL]&0x80);
        if((ctrl||alt)&&!altGr)return;
        WCHAR chars[8]{};
        // Bit 2 prevents ToUnicodeEx from mutating Windows' shared dead-key
        // buffer (Windows 10 1607+). Own the common accent composition below.
        int count=ToUnicodeEx(vk,MapVirtualKeyExW(vk,MAPVK_VK_TO_VSC,layout),state,chars,8,4,layout);
        if(count<0){
            if(dead_)emitUtf16(&dead_,1,emit);
            dead_=chars[0];return;
        }
        if(count<=0)return;
        if(count>8)count=8;
        if(dead_){
            WCHAR accent=dead_;dead_=0;
            if(count==1 && (chars[0]==L' ' || chars[0]==accent)){emitUtf16(&accent,1,emit);return;}
            WCHAR mark=combining(accent);
            if(mark && count==1){
                WCHAR pair[2]={chars[0],mark},normalized[8]{};
                int n=FoldStringW(MAP_PRECOMPOSED,pair,2,normalized,8);
                if(n==1){emitUtf16(normalized,n,emit);return;}
            }
            if(!emitUtf16(&accent,1,emit))return;
        }
        emitUtf16(chars,count,emit);
    }
public:
    // Call alongside IN_RELEASE_ALL, focus loss, lease loss and runtime shutdown.
    void reset(){pendingText_.clear();std::memset(held_,0,sizeof held_);std::memset(activeScan_,0,sizeof activeScan_);
        std::memset(repeatAt_,0,sizeof repeatAt_);dead_=0;menu_=false;layout_=nullptr;}
    // Emit must be bool(uint16_t type,uint16_t code,int a,int b,int c).
    // The caller MUST guard foreground ownership/physical permission first.
    template<class Emit,class Snapshot> void poll(bool screenOpen,Emit&& emit,Snapshot&& snapshot){
        if(!screenOpen)pendingText_.clear();
        DWORD thread=GetWindowThreadProcessId(GetForegroundWindow(),nullptr);
        HKL layout=GetKeyboardLayout(thread);
        if(layout!=layout_ || screenOpen!=menu_){
            dead_=0;layout_=layout;
            if(screenOpen){unsigned delay=1,speed=20;
                SystemParametersInfoW(SPI_GETKEYBOARDDELAY,0,&delay,0);
                SystemParametersInfoW(SPI_GETKEYBOARDSPEED,0,&speed,0);
                repeatDelay_=250*(1+(delay>3?3:delay));
                repeatInterval_=static_cast<unsigned>(1000.0/(2.5+27.5*(speed>31?31:speed)/31.0));}
            menu_=screenOpen;
            uint64_t now=GetTickCount64();for(int vk=0;vk<256;++vk)repeatAt_[vk]=now+repeatDelay_;
        }
        SHORT raw[256]{};BYTE state[256]{};
        GetKeyboardState(state);
        // Snapshot modifiers before generating any characters. Generic aliases
        // are not emitted separately, avoiding duplicate Shift/Ctrl/Alt keys.
        for(int vk=0;vk<256;++vk){
            if(vk==VK_SHIFT||vk==VK_CONTROL||vk==VK_MENU||vk==VK_F7||vk==VK_F11)continue;
            if(vkToSdl(vk,layout)==0)continue;
            raw[vk]=snapshot(vk); // Authoritative source, unaffected by ReShade Win32 filtering.
            state[vk]=(state[vk]&1)|((raw[vk]&0x8000)?0x80:0);
        }
        // ReShade may retain generic WM_KEYDOWN modifier identities. Prefer
        // sided states; use the left identity when only the generic is known.
        for(auto pair : {std::pair<int,int>{VK_SHIFT,VK_LSHIFT}, {VK_CONTROL,VK_LCONTROL}, {VK_MENU,VK_LMENU}}){
            int right=pair.second+1;
            if(!(raw[pair.second]&0x8000)&&!(raw[right]&0x8000)){
                raw[pair.second]=snapshot(pair.first);
                state[pair.second]=(raw[pair.second]&0x8000)?0x80:0;
            }
        }
        state[VK_SHIFT]=state[VK_LSHIFT]|state[VK_RSHIFT];
        state[VK_CONTROL]=state[VK_LCONTROL]|state[VK_RCONTROL];
        state[VK_MENU]=state[VK_LMENU]|state[VK_RMENU];
        const uint64_t now=GetTickCount64();
        // Modifiers must precede ordinary keys so Minecraft sees a complete
        // modifier state for Ctrl shortcuts even when keys land in one frame.
        const int modifiers[]={VK_LSHIFT,VK_RSHIFT,VK_LCONTROL,VK_RCONTROL,VK_LMENU,VK_RMENU,VK_LWIN,VK_RWIN};
        auto update=[&](int vk){
            if(vk==VK_SHIFT||vk==VK_CONTROL||vk==VK_MENU||vk==VK_F7||vk==VK_F11)return;
            int sc=vkToSdl(vk,layout);if(!sc)return;
            bool down=(raw[vk]&0x8000)!=0;
            if(!down && held_[vk]){
                if(emit(1,activeScan_[vk],0,0,0)){held_[vk]=false;activeScan_[vk]=0;}
                return;
            }
            if(down&&!held_[vk]){
                if(emit(1,sc,1,0,0)){held_[vk]=true;activeScan_[vk]=sc;repeatAt_[vk]=now+repeatDelay_;
                    if(screenOpen)text(vk,state,layout,emit);}
            }else if(down&&screenOpen&&menuRepeats(vk)&&now>=repeatAt_[vk]){
                if(emit(1,activeScan_[vk],1,0,0)){repeatAt_[vk]=now+repeatInterval_;text(vk,state,layout,emit);}
            }else if(!down&&(raw[vk]&1)&&!held_[vk]){
                // A release observed without a held key preserves one completed
                // tap between frames. Multiple taps may still coalesce.
                if(emit(1,sc,1,0,0)){held_[vk]=true;activeScan_[vk]=sc;
                    if(screenOpen)text(vk,state,layout,emit);
                    if(emit(1,sc,0,0,0)){held_[vk]=false;activeScan_[vk]=0;}}
            }
        };
        for(int vk:modifiers)update(vk);
        for(int vk=0;vk<256;++vk){bool modifier=false;for(int m:modifiers)if(vk==m)modifier=true;
            if(!modifier)update(vk);}
        while(!pendingText_.empty()){
            if(!emit(5,0,pendingText_.front(),0,0))break;
            pendingText_.pop_front();
        }
    }
    template<class Emit> void poll(bool screenOpen,Emit&& emit){
        poll(screenOpen,emit,[](int vk){return GetAsyncKeyState(vk);});
    }
};
} // namespace hyrulecraft

