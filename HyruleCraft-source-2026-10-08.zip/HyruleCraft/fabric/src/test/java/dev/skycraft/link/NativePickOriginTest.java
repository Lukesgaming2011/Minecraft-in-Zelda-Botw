package dev.skycraft.link;
import java.lang.foreign.Arena;
import java.lang.foreign.MemorySegment;
import static java.lang.foreign.ValueLayout.*;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import net.minecraft.world.phys.Vec3;
class NativePickOriginTest {
 private final Vec3 vanilla=new Vec3(0,1.62,0);
 private MemorySegment camera(Arena arena) {
  var m=arena.allocate(0xd00,8);m.set(JAVA_INT,0,Proto.MAGIC);m.set(JAVA_INT,4,Proto.VERSION);m.set(JAVA_LONG,0x10,1000);
  m.set(JAVA_INT,0x204,261);m.set(JAVA_INT,0xc00,2);m.set(JAVA_INT,0xc04,0x41434348);m.set(JAVA_DOUBLE,0xc10,1.56);return m;
 }
 @Test void usesFreshNativeEyeInsteadOfPlayerHeight() {try(var a=Arena.ofConfined()){var m=camera(a);assertEquals(new Vec3(0,1.56,0),NativePickOrigin.read(m,1000,vanilla));}}
 @Test void staleOrFutureTimestampFallsBack() {try(var a=Arena.ofConfined()){var m=camera(a);assertSame(vanilla,NativePickOrigin.read(m,1501,vanilla));assertSame(vanilla,NativePickOrigin.read(m,999,vanilla));}}
 @Test void oddSequenceAndWrongTagFallBack() {try(var a=Arena.ofConfined()){var m=camera(a);m.set(JAVA_INT,0xc00,3);assertSame(vanilla,NativePickOrigin.read(m,1000,vanilla));m.set(JAVA_INT,0xc00,2);m.set(JAVA_INT,0xc04,0);assertSame(vanilla,NativePickOrigin.read(m,1000,vanilla));}}
 @Test void thirdPersonAndRemoteEyeFallBack() {try(var a=Arena.ofConfined()){var m=camera(a);m.set(JAVA_INT,0x2c0,1);assertSame(vanilla,NativePickOrigin.read(m,1000,vanilla));m.set(JAVA_INT,0x2c0,0);m.set(JAVA_DOUBLE,0xc08,1);assertSame(vanilla,NativePickOrigin.read(m,1000,vanilla));}}
 @Test void sneakingUsesNativeEyeButDeathFallsBack() {try(var a=Arena.ofConfined()){var m=camera(a);m.set(JAVA_INT,0x204,261|Proto.MC_SNEAKING);assertEquals(new Vec3(0,1.56,0),NativePickOrigin.read(m,1000,new Vec3(0,1.27,0)));m.set(JAVA_INT,0x204,261|Proto.MC_DEAD);assertSame(vanilla,NativePickOrigin.read(m,1000,vanilla));}}
 @Test void nonfiniteAndMenuFallBack() {try(var a=Arena.ofConfined()){var m=camera(a);m.set(JAVA_DOUBLE,0xc08,Double.NaN);assertSame(vanilla,NativePickOrigin.read(m,1000,vanilla));m.set(JAVA_DOUBLE,0xc08,0);m.set(JAVA_INT,0x204,263);assertSame(vanilla,NativePickOrigin.read(m,1000,vanilla));}}
}
