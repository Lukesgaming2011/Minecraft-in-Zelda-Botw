package dev.skycraft.world;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
class TrackingGuardTest {
 @Test void stopsBeforeHorizontalRunaway(){assertFalse(TrackingGuard.allows(1.95,0,0,.1,0,0,0,0,0));}
 @Test void permitsRecovery(){assertTrue(TrackingGuard.allows(3,0,0,-.1,0,0,0,0,0));}
 @Test void limitsDiagonalSeparation(){assertFalse(TrackingGuard.allows(1.4,0,1.4,.1,0,.1,0,0,0));}
 @Test void allowsRoofSupportAndOrdinaryJump(){assertTrue(TrackingGuard.allows(0,3,0,.1,.42,0,0,0,0));}
 @Test void blocksVerticalRunawayAndAllowsDescent(){assertFalse(TrackingGuard.allows(0,6,0,0,.1,0,0,0,0));assertTrue(TrackingGuard.allows(0,7,0,0,-.1,0,0,0,0));}
 @Test void rejectsNonfiniteHost(){assertFalse(TrackingGuard.allows(0,0,0,.1,0,0,Double.NaN,0,0));}
}
