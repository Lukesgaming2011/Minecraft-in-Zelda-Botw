package dev.skycraft.world;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
class SpawnEscapeTest {
 @Test void unobstructedRoomDoesNotMovePlayer() { assertEquals(0,SpawnEscape.rise(0,dy->true)); }
 @Test void embeddedFullFloorFindsTop() { assertEquals(.75,SpawnEscape.rise(0,dy->dy>=.75)); }
 @Test void slabAndNativeGroundAreBothRespected() { assertEquals(.3125,SpawnEscape.rise(.3,dy->dy>=.3125)); }
 @Test void ceilingMustClearWholePlayerBody() { assertEquals(3,SpawnEscape.rise(0,dy->dy>=3)); }
 @Test void blockedOrUnknownBodyNeverUnlocks() { assertTrue(Double.isNaN(SpawnEscape.rise(0,dy->false))); }
 @Test void unreasonableGroundRiseIsRejected() { assertTrue(Double.isNaN(SpawnEscape.rise(5,dy->true))); assertTrue(Double.isNaN(SpawnEscape.rise(Double.NaN,dy->true))); }
}
