// MIT, HyruleCraft. SkyCraft protocol and mesh format: copyright chasmlol.
#include <windows.h>
#include <GL/gl.h>
#include <reshade.hpp>
#include <algorithm>
#include <array>
#include <cmath>
#include <cstring>
#include <map>
#include <vector>
#include <cstdio>
#include "../protocol/skycraft_protocol.h"
#include "keyboard_input.h"
#include "mouse_buttons.h"
#include "presentation_gate.h"
#include "scene_viewport.h"
using namespace reshade::api;
namespace p = skycraft::proto;
namespace {
uint8_t *shared = nullptr;
HANDLE mapping = nullptr;
uint64_t messages = 0, frames = 0;
bool inputEnabled=false;
hyrulecraft::PresentationGate presentationGate;
bool overlayReady=false;
bool presentationNoted=false;
bool userToggledOff=false;
bool lastF7Down=false;
bool lastF11Down=false;
bool pendingRelease=false;
hyrulecraft::MouseButtons mouseButtons;
hyrulecraft::KeyboardInput keyboardInput;
uint32_t cursorX=0,cursorY=0;
bool capturedMouse=false;
bool menuCursorValid=false;
int pendingWheel=0;
uint32_t mouseReadFailures=0,mouseWarpFailures=0,mouseSamples=0;
uint32_t totalDeltaX=0,totalDeltaY=0;
LONG lastClientW=0,lastClientH=0;
bool input(uint16_t type,uint16_t code,int a,int b,int c);
int front = 2;
effect_runtime *owner = nullptr;
// Hide only our focused TV window's cursor. Never replace system cursors or
// change ShowCursor's display counter, which would affect other applications.
HWND cursorWindow=nullptr;
WNDPROC cursorOriginal=nullptr;
bool hideFocusedCursor() {
    if(!cursorWindow||!shared)return false;
    uint32_t allowed;uint64_t beat;
    memcpy(&allowed,shared+0xc68,sizeof allowed);
    memcpy(&beat,shared+0x10,sizeof beat);
    const auto now=GetTickCount64();
    uint32_t screen,enabled,status;
    memcpy(&screen,shared+0x204,4);memcpy(&enabled,shared+0xc48,4);memcpy(&status,shared+0xcc8,4);
    return allowed&&enabled&&(status&2)&&!(screen&p::kMcScreenOpen)&&beat&&now>=beat&&now-beat<=500&&
        GetForegroundWindow()==GetAncestor(cursorWindow,GA_ROOT);
}
// F11 changes only the isolated TV window; its prior window state is restored.
HWND fullscreenRoot=nullptr;LONG_PTR savedStyle=0,savedExStyle=0;
WINDOWPLACEMENT savedPlacement{sizeof(WINDOWPLACEMENT)};HMENU savedMenu=nullptr;
void toggleFullscreen(HWND child) {
    HWND root=GetAncestor(child,GA_ROOT);
    if(fullscreenRoot==root){
        SetWindowLongPtrW(root,GWL_STYLE,savedStyle);SetWindowLongPtrW(root,GWL_EXSTYLE,savedExStyle);
        SetMenu(root,savedMenu);SetWindowPlacement(root,&savedPlacement);
        SetWindowPos(root,nullptr,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOZORDER|SWP_FRAMECHANGED);
        fullscreenRoot=nullptr;
    }else{
        MONITORINFO mi{sizeof(MONITORINFO)};
        if(!GetMonitorInfoW(MonitorFromWindow(root,MONITOR_DEFAULTTONEAREST),&mi))return;
        savedPlacement.length=sizeof(savedPlacement);if(!GetWindowPlacement(root,&savedPlacement))return;
        savedStyle=GetWindowLongPtrW(root,GWL_STYLE);savedExStyle=GetWindowLongPtrW(root,GWL_EXSTYLE);savedMenu=GetMenu(root);
        fullscreenRoot=root;SetMenu(root,nullptr);
        SetWindowLongPtrW(root,GWL_STYLE,(savedStyle&~WS_OVERLAPPEDWINDOW)|WS_POPUP);
        SetWindowLongPtrW(root,GWL_EXSTYLE,savedExStyle&~(WS_EX_WINDOWEDGE|WS_EX_CLIENTEDGE));
        SetWindowPos(root,nullptr,mi.rcMonitor.left,mi.rcMonitor.top,mi.rcMonitor.right-mi.rcMonitor.left,mi.rcMonitor.bottom-mi.rcMonitor.top,SWP_NOZORDER|SWP_FRAMECHANGED);
    }
}
LRESULT CALLBACK cursorProc(HWND win,UINT msg,WPARAM wp,LPARAM lp) {
    if(msg==WM_APP+0x48){toggleFullscreen(win);return 0;}
    if(msg==WM_SETCURSOR&&hideFocusedCursor()){
        SetCursor(nullptr);return TRUE;
    }
    const auto original=cursorOriginal;
    return original?CallWindowProcW(original,win,msg,wp,lp):DefWindowProcW(win,msg,wp,lp);
}
void restoreCursorWindow() {
    if(cursorWindow&&IsWindow(cursorWindow)&&
        reinterpret_cast<WNDPROC>(GetWindowLongPtrW(cursorWindow,GWLP_WNDPROC))==cursorProc)
        SetWindowLongPtrW(cursorWindow,GWLP_WNDPROC,reinterpret_cast<LONG_PTR>(cursorOriginal));
    cursorWindow=nullptr;cursorOriginal=nullptr;
}
void updateCursorWindow(effect_runtime *rt) {
    HWND win=reinterpret_cast<HWND>(rt->get_hwnd());
    if(win!=cursorWindow){
        restoreCursorWindow();
        if(IsWindow(win)){
            SetLastError(0);
            auto original=reinterpret_cast<WNDPROC>(SetWindowLongPtrW(win,GWLP_WNDPROC,reinterpret_cast<LONG_PTR>(cursorProc)));
            if(original){cursorOriginal=original;cursorWindow=win;}
        }
    }
    if(hideFocusedCursor())SetCursor(nullptr);
    else if(cursorWindow&&GetForegroundWindow()==GetAncestor(cursorWindow,GA_ROOT))SetCursor(LoadCursorW(nullptr,MAKEINTRESOURCEW(32512)));
}

// Avoid compiler-specific aggregate return conventions at this API boundary.
// Enumeration and its callback use only pointer/scalar arguments.
effect_uniform_variable findUniform(effect_runtime *rt,const char *effect,const char *name) {
    struct Context {const char *name;effect_uniform_variable found;} ctx{name,{}};
    rt->enumerate_uniform_variables(effect,[](effect_runtime *runtime,effect_uniform_variable variable,void *userdata){
        auto c=static_cast<Context*>(userdata);char label[128];size_t size=sizeof label;
        runtime->get_uniform_variable_name(variable,label,&size);
        if(!strcmp(label,c->name))c->found=variable;
    },&ctx);
    return ctx.found;
}
struct Layer { resource tex{}; resource_view view{}; } world, distanceLayer, overlay, depth;
GLuint fbo=0, program=0, vao=0, vbo=0, atlas=0;
uint32_t width=0,height=0;
uint32_t atlasWidth=0,atlasHeight=0;
struct Section { std::vector<p::RenVertex> vertices; };
std::map<std::array<int,3>,Section> sections;
struct EntityTex { GLuint handle{0}; uint32_t width{0}, height{0}; };
std::unordered_map<uint32_t, EntityTex> entityTextures;
struct AvatarBatch { uint32_t texture, first, count, translucent; };
std::vector<AvatarBatch> avatarBatches;
std::vector<p::RenVertex> avatarVertices;
GLuint avatarVbo = 0;
#define FN(ret,n,args) ret (APIENTRY *n) args = nullptr
FN(void,GenFramebuffers,(GLsizei,GLuint*)); FN(void,BindFramebuffer,(GLenum,GLuint));
FN(void,FramebufferTexture2D,(GLenum,GLenum,GLenum,GLuint,GLint)); FN(void,DrawBuffers,(GLsizei,const GLenum*));
FN(void,GenVertexArrays,(GLsizei,GLuint*)); FN(void,BindVertexArray,(GLuint));
FN(void,GenBuffers,(GLsizei,GLuint*)); FN(void,BindBuffer,(GLenum,GLuint)); FN(void,BufferData,(GLenum,ptrdiff_t,const void*,GLenum));
FN(GLuint,CreateShader,(GLenum)); FN(void,ShaderSource,(GLuint,GLsizei,const char*const*,const GLint*));
FN(void,CompileShader,(GLuint)); FN(void,GetShaderiv,(GLuint,GLenum,GLint*)); FN(void,GetShaderInfoLog,(GLuint,GLsizei,GLsizei*,char*));
FN(GLuint,CreateProgram,()); FN(void,AttachShader,(GLuint,GLuint)); FN(void,LinkProgram,(GLuint));
FN(void,GetProgramiv,(GLuint,GLenum,GLint*)); FN(void,UseProgram,(GLuint));
FN(void,EnableVertexAttribArray,(GLuint)); FN(void,VertexAttribPointer,(GLuint,GLint,GLenum,GLboolean,GLsizei,const void*));
FN(GLint,GetUniformLocation,(GLuint,const char*)); FN(void,Uniform3f,(GLint,GLfloat,GLfloat,GLfloat));
FN(void,Uniform1f,(GLint,GLfloat)); FN(void,Uniform1i,(GLint,GLint)); FN(void,ActiveTexture,(GLenum));
FN(void,ClearBufferfv,(GLenum,GLint,const GLfloat*));
FN(void,ClipControl,(GLenum,GLenum));
#undef FN
template<class T> bool load(T &fn,const char *name) { fn=reinterpret_cast<T>(wglGetProcAddress(name));return fn != nullptr; }
void note(const char *text) { reshade::log::message(reshade::log::level::info,text); }
bool initGL() {
#define LOAD(n) if(!load(n,"gl" #n)) return false
    LOAD(GenFramebuffers);LOAD(BindFramebuffer);LOAD(FramebufferTexture2D);LOAD(DrawBuffers);
    LOAD(GenVertexArrays);LOAD(BindVertexArray);LOAD(GenBuffers);LOAD(BindBuffer);LOAD(BufferData);
    LOAD(CreateShader);LOAD(ShaderSource);LOAD(CompileShader);LOAD(GetShaderiv);LOAD(GetShaderInfoLog);
    LOAD(CreateProgram);LOAD(AttachShader);LOAD(LinkProgram);LOAD(GetProgramiv);LOAD(UseProgram);
    LOAD(EnableVertexAttribArray);LOAD(VertexAttribPointer);LOAD(GetUniformLocation);LOAD(Uniform3f);
    LOAD(Uniform1f);LOAD(Uniform1i);LOAD(ActiveTexture);LOAD(ClearBufferfv);
    LOAD(ClipControl);
#undef LOAD
    const char *vs=R"GLSL(#version 330 core
layout(location=0) in vec3 pos;layout(location=1) in vec2 uv;layout(location=2) in vec4 tint;
uniform vec3 eye,forward,right,up,origin;uniform float focal,aspect;
out vec2 texUV;out vec4 color;out float metres;
void main(){vec3 q=pos+origin-eye;float z=dot(q,forward);float n=.05,f=512.;
gl_Position=vec4(dot(q,right)*focal/aspect,dot(q,up)*focal,((f+n)/(f-n))*z-2*f*n/(f-n),z);
texUV=uv;color=tint;metres=z;})GLSL";
    const char *fs=R"GLSL(#version 330 core
in vec2 texUV;in vec4 color;in float metres;uniform sampler2D atlas;
layout(location=0) out vec4 rgba;layout(location=1) out float viewDepth;
void main(){vec4 c=texture(atlas,texUV)*color;if(c.a<.1)discard;rgba=vec4(c.rgb*c.a,c.a);viewDepth=metres;})GLSL";
    auto compile=[](GLenum type,const char *s){GLuint sh=CreateShader(type);ShaderSource(sh,1,&s,nullptr);CompileShader(sh);
        GLint ok=0;GetShaderiv(sh,0x8B81,&ok);if(!ok){char log[2048];GetShaderInfoLog(sh,2048,nullptr,log);note(log);return GLuint(0);}return sh;};
    GLuint a=compile(0x8B31,vs),b=compile(0x8B30,fs);if(!a||!b)return false;
    program=CreateProgram();AttachShader(program,a);AttachShader(program,b);LinkProgram(program);
    GLint ok=0;GetProgramiv(program,0x8B82,&ok);if(!ok)return false;
    GenFramebuffers(1,&fbo);GenVertexArrays(1,&vao);GenBuffers(1,&vbo);glGenTextures(1,&atlas);
    note("HyruleCraft: OpenGL mesh renderer initialized");return true;
}
bool create(device *dev,Layer &l,uint32_t w,uint32_t h,format fmt,resource_usage usage) {
    if(!dev->create_resource(resource_desc(w,h,1,1,fmt,1,memory_heap::default_,usage),nullptr,usage,&l.tex))return false;
    return dev->create_resource_view(l.tex,resource_usage::shader_resource,resource_view_desc(fmt),&l.view);
}
void release(effect_runtime *rt) {
    if(owner==rt)restoreCursorWindow();
    if(!rt || rt!=owner)return;
    presentationGate.reset();overlayReady=false;presentationNoted=false;
    if(shared){
        InterlockedExchange(reinterpret_cast<volatile LONG*>(shared+0xc74),0);
        InterlockedExchange(reinterpret_cast<volatile LONG*>(shared+0xc48),0);
        InterlockedExchange(reinterpret_cast<volatile LONG*>(shared+0xc70),0);
        InterlockedExchange(reinterpret_cast<volatile LONG*>(shared+0xc70),0);
        InterlockedExchange(reinterpret_cast<volatile LONG*>(shared+0xc54),0);
        InterlockedExchange(reinterpret_cast<volatile LONG*>(shared+0xc58),0);
        InterlockedExchange(reinterpret_cast<volatile LONG*>(shared+0xc5c),0);
        if(inputEnabled)input(p::kInReleaseAll,0,0,0,0);
    }
    inputEnabled=false;capturedMouse=false;userToggledOff=false;lastF7Down=false;keyboardInput.reset();mouseButtons.reset();menuCursorValid=false;pendingWheel=0;
    auto dev=rt->get_device();
    for(auto l:{&world,&distanceLayer,&overlay,&depth}){if(l->view.handle)dev->destroy_resource_view(l->view);if(l->tex.handle)dev->destroy_resource(l->tex);*l={};}
    owner=nullptr;width=height=0;
}
bool allocate(effect_runtime *rt,uint32_t w,uint32_t h) {
    if(owner==rt&&width==w&&height==h)return true;
    if(owner)release(owner);owner=rt;
    auto dev=rt->get_device();auto usage=resource_usage::shader_resource|resource_usage::render_target|resource_usage::copy_dest;
    if(!create(dev,world,w,h,format::r8g8b8a8_unorm,usage)||!create(dev,distanceLayer,w,h,format::r32_float,usage)||
       !create(dev,overlay,w,h,format::r8g8b8a8_unorm,resource_usage::shader_resource|resource_usage::copy_dest)||
       !create(dev,depth,w,h,format::d32_float,resource_usage::shader_resource|resource_usage::depth_stencil)){release(rt);return false;}
    width=w;height=h;
    rt->update_texture_bindings("HCWORLD",world.view,world.view);
    rt->update_texture_bindings("HCDEPTH",distanceLayer.view,distanceLayer.view);
    rt->update_texture_bindings("HCOVERLAY",overlay.view,overlay.view);
    return true;
}
bool connect() {
    if(shared)return true;
    mapping=OpenFileMappingW(FILE_MAP_ALL_ACCESS,FALSE,p::kMappingName);if(!mapping)return false;
    shared=static_cast<uint8_t*>(MapViewOfFile(mapping,FILE_MAP_ALL_ACCESS,0,0,p::kMappingBytes));
    if(!shared){CloseHandle(mapping);mapping=nullptr;return false;}
    auto h=reinterpret_cast<p::Header*>(shared);
    if(h->magic!=p::kMagic||h->version!=p::kVersion){UnmapViewOfFile(shared);CloseHandle(mapping);shared=nullptr;return false;}
    note("HyruleCraft: connected to Minecraft protocol 12");return true;
}
template<class T>T read(size_t offset){T value;memcpy(&value,shared+offset,sizeof value);return value;}
bool input(uint16_t type,uint16_t code=0,int a=0,int b=0,int c=0) {
    if(type==p::kInReleaseAll)pendingRelease=true;
    auto enqueue=[&](uint16_t t,uint16_t key,int x,int y,int z){
        uint64_t head=read<uint64_t>(0x1000),tail=read<uint64_t>(0x1040);
        if(head<tail||head-tail>=4096)return false;
        struct Event {uint16_t type,code;int a,b,c;} event{t,key,x,y,z};
        memcpy(shared+0x1080+(head%4096)*16,&event,16);MemoryBarrier();
        InterlockedExchange64(reinterpret_cast<volatile LONG64*>(shared+0x1000),head+1);return true;
    };
    // Releases always precede newly acquired input; retain them on backpressure.
    if(pendingRelease){if(!enqueue(p::kInReleaseAll,0,0,0,0))return false;pendingRelease=false;}
    return type==p::kInReleaseAll || enqueue(type,code,a,b,c);
}
void pollInput(effect_runtime *rt) {
    InterlockedExchange64(reinterpret_cast<volatile LONG64*>(shared+0xc60),GetTickCount64());
    // Host startup uses the same windowed/fullscreen state as F11. Native Cemu
    // fullscreen and an independent borderless toggle must not compete.
    const auto displayRequest=read<uint32_t>(0xce0);
    if(cursorWindow&&(displayRequest==1||displayRequest==2)){
        InterlockedExchange(reinterpret_cast<volatile LONG*>(shared+0xce0),0);
        if((displayRequest==1&&!fullscreenRoot)||(displayRequest==2&&fullscreenRoot))PostMessageW(cursorWindow,WM_APP+0x48,0,0);
    }
    HWND foreground=GetForegroundWindow();DWORD pid=0;GetWindowThreadProcessId(foreground,&pid);
    // A bounded host-owned probe may send MC events while physical capture stays off.
    // The renderer grants a fresh foreground acknowledgement and does not produce
    // competing input events during this lease. No OS mouse/key polling occurs.
    if((read<uint32_t>(0xc6c)==1 || read<uint32_t>(0xc6c)==2 || read<uint32_t>(0xc6c)==3 || read<uint32_t>(0xc6c)==4) && !read<uint32_t>(0xc68)){
        uint32_t grant=pid==GetCurrentProcessId()?1:0;
        memcpy(shared+0xc70,&grant,4);
        uint32_t disabled=0;memcpy(shared+0xc48,&disabled,4);
        inputEnabled=false;capturedMouse=false;keyboardInput.reset();mouseButtons.reset();menuCursorValid=false;pendingWheel=0;return;
    }
    if(pendingRelease)input(p::kInReleaseAll);
    uint32_t noProbe=0;memcpy(shared+0xc70,&noProbe,4);
    const bool desktopChord=read<uint8_t>(0xd00+VK_LMENU)||read<uint8_t>(0xd00+VK_MENU)||read<uint8_t>(0xd00+VK_LWIN)||read<uint8_t>(0xd00+VK_RWIN);
    const bool tvFocused=foreground==GetAncestor(reinterpret_cast<HWND>(rt->get_hwnd()),GA_ROOT);
    bool f11Down=read<uint8_t>(0xd00+VK_F11)!=0;
    if(tvFocused&&read<uint32_t>(0xc68)&&f11Down&&!lastF11Down)PostMessageW(reinterpret_cast<HWND>(rt->get_hwnd()),WM_APP+0x48,0,0);
    lastF11Down=f11Down;
    if(pid!=GetCurrentProcessId() || !tvFocused || desktopChord || !read<uint32_t>(0xc68)){
        InterlockedExchange(reinterpret_cast<volatile LONG*>(shared+0xc54),0);
        InterlockedExchange(reinterpret_cast<volatile LONG*>(shared+0xc58),0);
        InterlockedExchange(reinterpret_cast<volatile LONG*>(shared+0xc5c),0);
        uint32_t capZero=0;memcpy(shared+0xcb8,&capZero,4);
        input(p::kInReleaseAll);keyboardInput.reset();mouseButtons.reset();menuCursorValid=false;pendingWheel=0;
        inputEnabled=false;capturedMouse=false;lastF7Down=false;uint32_t disabled=0;memcpy(shared+0xc48,&disabled,4);return;
    }
    bool f7Down=read<uint8_t>(0xd00+VK_F7)!=0;
    bool f7Edge=f7Down&&!lastF7Down;
    lastF7Down=f7Down;
    if(f7Edge){
        userToggledOff=!userToggledOff;
        input(p::kInReleaseAll);keyboardInput.reset();mouseButtons.reset();menuCursorValid=false;pendingWheel=0;
        InterlockedExchange(reinterpret_cast<volatile LONG*>(shared+0xc54),0);
        InterlockedExchange(reinterpret_cast<volatile LONG*>(shared+0xc58),0);
        InterlockedExchange(reinterpret_cast<volatile LONG*>(shared+0xc5c),0);
        uint32_t capZero=0;memcpy(shared+0xcb8,&capZero,4);
        note(userToggledOff?"HyruleCraft: Minecraft input released":"HyruleCraft: Minecraft input enabled (F7 releases)");
    }
    bool active=!userToggledOff&&read<uint32_t>(0xc68);
    if(active!=inputEnabled){
        inputEnabled=active;
        if(inputEnabled)note("HyruleCraft: Minecraft input enabled (F7 releases)");
    }
    uint32_t enabled=inputEnabled?1:0;memcpy(shared+0xc48,&enabled,4);
    if(!inputEnabled){capturedMouse=false;uint32_t capZero=0;memcpy(shared+0xcb8,&capZero,4);return;}
    // The supported ReShade input gate prevents Minecraft keyboard shortcuts
    // and wheel/click messages from also acting on Cemu's menus/controller.
    rt->block_input_next_frame();
    keyboardInput.poll((read<uint32_t>(0x204)&p::kMcScreenOpen)!=0,
        [](uint16_t type,uint16_t code,int a,int b,int c){return input(type,code,a,b,c);},
        [](int vk){return SHORT(read<uint8_t>(0xd00+vk)?0x8000:0);});
    HWND win=(HWND)rt->get_hwnd();
    if(!win)win=foreground;
    RECT client{};
    GetClientRect(win,&client);
    LONG clientW=client.right-client.left;
    LONG clientH=client.bottom-client.top;

    if(clientW!=lastClientW||clientH!=lastClientH){
        capturedMouse=false;
        lastClientW=clientW;
        lastClientH=clientH;
    }

    uint32_t sceneW=(clientW>0&&clientH>0)?std::min(uint32_t(clientW),uint32_t((uint64_t(clientH)*16)/9)):0;
    uint32_t sceneH=(clientW>0&&clientH>0)?std::min(uint32_t(clientH),uint32_t((uint64_t(clientW)*9)/16)):0;
    LONG vpX=(clientW>LONG(sceneW))?(clientW-LONG(sceneW))/2:0;
    LONG vpY=(clientH>LONG(sceneH))?(clientH-LONG(sceneH))/2:0;

    POINT centerScreen{vpX+LONG(sceneW)/2,vpY+LONG(sceneH)/2};
    bool centerOk=(sceneW>0&&sceneH>0)&&ClientToScreen(win,&centerScreen);

    auto getCursor=[](POINT &pt)->bool{
        if(!(read<uint32_t>(0xcc8)&1))return false;
        pt.x=read<int32_t>(0xccc);pt.y=read<int32_t>(0xcd0);return true;
    };

    uint32_t dummyX=0,dummyY=0;int16_t wheel=0;
    rt->get_mouse_cursor_position(&dummyX,&dummyY,&wheel);

    bool screen=(read<uint32_t>(0x204)&p::kMcScreenOpen)!=0;
    if(screen){
        capturedMouse=false;
        uint32_t capZero=0;memcpy(shared+0xcb8,&capZero,4);
        POINT cursor{};
        if(getCursor(cursor)){
            memcpy(shared+0xca8,&cursor.x,4);
            memcpy(shared+0xcac,&cursor.y,4);
            if(ScreenToClient(win,&cursor)&&sceneW>0&&sceneH>0&&width>0&&height>0){
                LONG cx=std::clamp(cursor.x-vpX,0L,LONG(sceneW)-1);
                LONG cy=std::clamp(cursor.y-vpY,0L,LONG(sceneH)-1);
                uint32_t mx=uint32_t((uint64_t(cx)*width)/sceneW);
                uint32_t my=uint32_t((uint64_t(cy)*height)/sceneH);
                if((!menuCursorValid||mx!=cursorX||my!=cursorY)&&mx<width&&my<height&&input(p::kInCursor,0,mx,my)){
                    cursorX=mx;cursorY=my;menuCursorValid=true;
                }
            }
        }else{
            capturedMouse=false;
        }
    }else{
        menuCursorValid=false;
        if(centerOk){
            memcpy(shared+0xcb0,&centerScreen.x,4);
            memcpy(shared+0xcb4,&centerScreen.y,4);
            POINT cursor{};
            if(getCursor(cursor)){
                memcpy(shared+0xca8,&cursor.x,4);
                memcpy(shared+0xcac,&cursor.y,4);
                // Physical motion/warping belongs exclusively to the unhooked
                // host. Never query filtered Win32 cursor APIs from Cemu here.
                capturedMouse=(read<uint32_t>(0xcc8)&2)!=0;
            }else{
                capturedMouse=false;
            }
        }else{
            capturedMouse=false;
        }
        uint32_t capVal=capturedMouse?1:0;
        memcpy(shared+0xcb8,&capVal,4);
    }
    ++mouseSamples;
    memcpy(shared+0xcbc,&mouseSamples,4);
    pendingWheel=std::clamp(pendingWheel+int(wheel)*120,-12000,12000);
    if(pendingWheel&&input(p::kInScroll,0,pendingWheel))pendingWheel=0;
    // The host captures physical clicks before Cemu; pulse bits preserve fast clicks.
    uint32_t mouse=InterlockedAnd(reinterpret_cast<volatile LONG*>(shared+0xc5c),7);
    mouseButtons.update(mouse,[](uint16_t code,bool down){
        return input(p::kInMouseButton,code,int(down));
    });
}
void drain() {
    auto base=shared+p::kOffRenderRing;uint64_t head=read<uint64_t>(p::kOffRenderRing),tail=read<uint64_t>(p::kOffRenderRing+0x40);
    const uint64_t capacity=p::kRenderRingBytes-0x80;
    if(head<tail||head-tail>capacity)return;
    while(tail<head){auto pos=tail%capacity;if(capacity-pos<8){tail+=capacity-pos;continue;}
        uint32_t type,n;memcpy(&type,base+0x80+pos,4);memcpy(&n,base+0x84+pos,4);
        if(!type){tail+=capacity-pos;continue;}uint64_t step=(uint64_t(8)+n+7)&~uint64_t(7);
        if(step>capacity-pos||step>head-tail)break;const uint8_t *data=base+0x88+pos;
        if(type==p::kRenClearAll){sections.clear();avatarBatches.clear();avatarVertices.clear();}
        else if(type==p::kRenSection&&n>=16){p::RenSection s;memcpy(&s,data,16);
            if(s.vertexCount<=1000000&&n==16+uint64_t(s.vertexCount)*32){auto key=std::array<int,3>{s.sx,s.sy,s.sz};auto &v=sections[key].vertices;
                v.resize(s.vertexCount);memcpy(v.data(),data+16,v.size()*32);if(v.empty())sections.erase(key);}}
        else if(type==p::kRenAtlas&&n>=8){uint32_t w,h;memcpy(&w,data,4);memcpy(&h,data+4,4);
            if(w&&h&&w<=8192&&h<=8192&&n==8+uint64_t(w)*h*4){glBindTexture(GL_TEXTURE_2D,atlas);glPixelStorei(GL_UNPACK_ALIGNMENT,1);
                glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
                glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,w,h,0,GL_RGBA,GL_UNSIGNED_BYTE,data+8);atlasWidth=w;atlasHeight=h;}}
        else if(type==p::kRenAtlasRegion&&n>=16&&atlasWidth){uint32_t x,y,w,h;memcpy(&x,data,4);memcpy(&y,data+4,4);memcpy(&w,data+8,4);memcpy(&h,data+12,4);
            if(x+w<=atlasWidth&&y+h<=atlasHeight&&n==16+uint64_t(w)*h*4){glBindTexture(GL_TEXTURE_2D,atlas);glPixelStorei(GL_UNPACK_ALIGNMENT,1);glTexSubImage2D(GL_TEXTURE_2D,0,x,y,w,h,GL_RGBA,GL_UNSIGNED_BYTE,data+16);}}
        else if(type==p::kRenTexture&&n>=16){uint32_t id,tw,th,flags;memcpy(&id,data,4);memcpy(&tw,data+4,4);memcpy(&th,data+8,4);memcpy(&flags,data+12,4);
            if(id&&tw&&th&&tw<=4096&&th<=4096&&n>=16+uint64_t(tw)*th*4){auto &t=entityTextures[id];
                if(!t.handle)glGenTextures(1,&t.handle);t.width=tw;t.height=th;glBindTexture(GL_TEXTURE_2D,t.handle);glPixelStorei(GL_UNPACK_ALIGNMENT,1);
                glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST);glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST);
                glTexParameteri(GL_TEXTURE_2D,0x2802,0x812F);glTexParameteri(GL_TEXTURE_2D,0x2803,0x812F);
                glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,tw,th,0,GL_RGBA,GL_UNSIGNED_BYTE,data+16);}}
        else if(type==p::kRenAvatar&&n>=8){uint32_t batchCount,vertexCount;memcpy(&batchCount,data,4);memcpy(&vertexCount,data+4,4);
            avatarBatches.clear();avatarVertices.clear();uint64_t headSize=8+uint64_t(batchCount)*16;
            if(vertexCount>0&&vertexCount<=100000&&n>=headSize+uint64_t(vertexCount)*32){
                for(uint32_t i=0;i<batchCount;++i){AvatarBatch b;memcpy(&b,data+8+i*16,16);if(b.first+b.count<=vertexCount)avatarBatches.push_back(b);}
                avatarVertices.resize(vertexCount);memcpy(avatarVertices.data(),data+headSize,vertexCount*sizeof(p::RenVertex));}}
        ++messages;tail+=step;
    }
    MemoryBarrier();InterlockedExchange64(reinterpret_cast<volatile LONG64*>(base+0x40),tail);
}
// Logged before the MC mapping connects: these are Cemu's native game
// depth resources, not the compositor's own later allocations.
void nativeResource(device*,const resource_desc& desc,const subresource_data*,resource_usage,resource) {
    if(!shared && desc.type==resource_type::texture_2d && desc.texture.width>=1000 && desc.texture.height>=700){
        char log[160];snprintf(log,sizeof log,"HyruleCraft: native game target=%ux%u format=%u",desc.texture.width,desc.texture.height,unsigned(desc.texture.format));note(log);
    }
}
void uniform3(const char *name,float x,float y,float z){Uniform3f(GetUniformLocation(program,name),x,y,z);}
void begin(effect_runtime *rt,command_list*,resource_view,resource_view) {
    auto active=findUniform(rt,"HyruleCraft.fx","HyruleActive");
    if(rt->get_device()->get_api()!=device_api::opengl||!connect()){
        if(active.handle)rt->set_uniform_value_bool(active,false);return;}
    if(GetTickCount64()-read<uint64_t>(0x10)>500||GetTickCount64()-read<uint64_t>(0x18)>500){
        const bool retain=presentationGate.retainDuringPause(GetTickCount64(),read<uint64_t>(0x10),read<uint64_t>(0x18));
        if(!retain){presentationGate.reset();overlayReady=false;presentationNoted=false;}
        InterlockedExchange(reinterpret_cast<volatile LONG*>(shared+0xc74),0);
        if(active.handle)rt->set_uniform_value_bool(active,retain);
        InterlockedExchange(reinterpret_cast<volatile LONG*>(shared+0xc48),0);
        InterlockedExchange(reinterpret_cast<volatile LONG*>(shared+0xc5c),0);
        if(inputEnabled)input(p::kInReleaseAll);
        inputEnabled=false;capturedMouse=false;keyboardInput.reset();mouseButtons.reset();menuCursorValid=false;pendingWheel=0;return;}
    // One runtime only: Cemu's main TV surface. The Wii U gamepad is a separate runtime.
    uint32_t w,h;rt->get_screenshot_width_and_height(&w,&h);if(w<640||h<360)return;
    if(owner&&owner!=rt)return;
    updateCursorWindow(rt);
    memcpy(shared+0xc40,&w,4);memcpy(shared+0xc44,&h,4);
    // Saving/quitting ends overlay production. Never leave its last pause screen
    // painted over BOTW or keep its input ownership after the world is gone.
    if(!(read<uint32_t>(0x204)&p::kMcInWorld)){
        presentationGate.reset();overlayReady=false;presentationNoted=false;
        InterlockedExchange(reinterpret_cast<volatile LONG*>(shared+0xc74),0);
        if(active.handle)rt->set_uniform_value_bool(active,false);
        InterlockedExchange(reinterpret_cast<volatile LONG*>(shared+0xc48),0);
        InterlockedExchange(reinterpret_cast<volatile LONG*>(shared+0xc5c),0);
        if(inputEnabled)input(p::kInReleaseAll);
        inputEnabled=false;capturedMouse=false;userToggledOff=false;lastF7Down=false;sections.clear();
        keyboardInput.reset();mouseButtons.reset();menuCursorValid=false;pendingWheel=0;return;
    }
    if(!program&&!initGL())return;
    GLint oldFbo,oldReadFbo,oldProgram,oldVao,oldBuffer,oldActive,oldTexture,oldViewport[4],oldUnpack,oldUnpackRow,oldOrigin,oldClip;
    glGetIntegerv(0x8CA6,&oldFbo);glGetIntegerv(0x8CAA,&oldReadFbo);glGetIntegerv(0x8B8D,&oldProgram);glGetIntegerv(0x85B5,&oldVao);
    glGetIntegerv(0x8894,&oldBuffer);glGetIntegerv(0x84E0,&oldActive);ActiveTexture(0x84C0);glGetIntegerv(GL_TEXTURE_BINDING_2D,&oldTexture);
    glGetIntegerv(GL_VIEWPORT,oldViewport);glGetIntegerv(GL_UNPACK_ALIGNMENT,&oldUnpack);glGetIntegerv(GL_UNPACK_ROW_LENGTH,&oldUnpackRow);
    glGetIntegerv(0x935C,&oldOrigin);glGetIntegerv(0x935D,&oldClip);ClipControl(0x8CA1,0x935E);
    GLboolean oldDepth=glIsEnabled(GL_DEPTH_TEST),oldBlend=glIsEnabled(GL_BLEND),oldCull=glIsEnabled(GL_CULL_FACE),oldScissor=glIsEnabled(GL_SCISSOR_TEST),oldMask;
    GLint oldDepthFunc;glGetIntegerv(GL_DEPTH_FUNC,&oldDepthFunc);glGetBooleanv(GL_DEPTH_WRITEMASK,&oldMask);
    GLboolean colorMask[4];glGetBooleanv(GL_COLOR_WRITEMASK,colorMask);GLboolean oldSRGB=glIsEnabled(0x8DB9);
    glPixelStorei(GL_UNPACK_ROW_LENGTH,0);drain();
    // Publish avatar readiness only after a complete accepted packet. The host
    // uses it to lease native model hiding; no skin means Link stays visible.
    uint32_t avatarReady=!avatarBatches.empty()&&!avatarVertices.empty();
    // Avatar hiding is published after the presentation gate below.
    if(allocate(rt,w,h)){
        pollInput(rt);
        BindFramebuffer(0x8D40,fbo);FramebufferTexture2D(0x8D40,0x8CE0,GL_TEXTURE_2D,GLuint(world.tex.handle),0);
        FramebufferTexture2D(0x8D40,0x8CE1,GL_TEXTURE_2D,GLuint(distanceLayer.tex.handle),0);FramebufferTexture2D(0x8D40,0x8D00,GL_TEXTURE_2D,GLuint(depth.tex.handle),0);
        const GLenum attachments[]={0x8CE0,0x8CE1};DrawBuffers(2,attachments);
        auto scene=hyrulecraft::sceneViewport(w,h,read<float>(0xc38));
        uint32_t sceneHeight=scene.height;glViewport(scene.x,scene.y,scene.width,scene.height);
        auto scale=findUniform(rt,"HyruleCraft.fx","SceneScaleY");if(scale.handle)rt->set_uniform_value_float(scale,float(h)/sceneHeight);
        glDisable(GL_BLEND);glDisable(GL_CULL_FACE);glDisable(GL_SCISSOR_TEST);glDisable(0x8DB9);glColorMask(1,1,1,1);glEnable(GL_DEPTH_TEST);glDepthMask(1);glDepthFunc(GL_LESS);
        const float zero[4]={0,0,0,0},one[4]={1,1,1,1};ClearBufferfv(0x1800,0,zero);ClearBufferfv(0x1800,1,zero);ClearBufferfv(0x1801,0,one);
        // Custom camera extension @0xC00, seqlocked by the BOTW bridge.
        struct Camera {uint32_t seq,magic;double x,y,z;float dx,dy,dz,fov,nearPlane,farPlane,aspect;uint32_t projectionValid;} camera{};
        uint32_t a=read<uint32_t>(0xc00);memcpy(&camera,shared+0xc00,sizeof camera);MemoryBarrier();
        if(!(a&1)&&a==read<uint32_t>(0xc00)&&camera.magic==0x41434348&&camera.projectionValid==1&&camera.nearPlane>0&&camera.farPlane>camera.nearPlane&&camera.aspect>0){
            auto nearUniform=findUniform(rt,"HyruleCraft.fx","HostNear"),farUniform=findUniform(rt,"HyruleCraft.fx","HostFar");
            if(nearUniform.handle)rt->set_uniform_value_float(nearUniform,camera.nearPlane);
            if(farUniform.handle)rt->set_uniform_value_float(farUniform,camera.farPlane);
            float rx=camera.dz,rz=-camera.dx,rlen=std::sqrt(rx*rx+rz*rz);if(rlen>0.001){rx/=rlen;rz/=rlen;
                float ux=camera.dy*rz,uy=camera.dz*rx-camera.dx*rz,uz=-camera.dy*rx;
                UseProgram(program);uniform3("eye",camera.x,camera.y,camera.z);uniform3("forward",camera.dx,camera.dy,camera.dz);
                uniform3("right",rx,0,rz);uniform3("up",ux,uy,uz);Uniform1f(GetUniformLocation(program,"focal"),1/std::tan(camera.fov*3.14159265f/360));
                Uniform1f(GetUniformLocation(program,"aspect"),camera.aspect);Uniform1i(GetUniformLocation(program,"atlas"),0);
                glBindTexture(GL_TEXTURE_2D,atlas);BindVertexArray(vao);BindBuffer(0x8892,vbo);
                EnableVertexAttribArray(0);VertexAttribPointer(0,3,GL_FLOAT,0,32,nullptr);EnableVertexAttribArray(1);VertexAttribPointer(1,2,GL_FLOAT,0,32,reinterpret_cast<void*>(12));
                EnableVertexAttribArray(2);VertexAttribPointer(2,4,GL_UNSIGNED_BYTE,1,32,reinterpret_cast<void*>(20));
                for(auto &[key,s]:sections){if(std::abs(key[0]*16-camera.x)>96||std::abs(key[1]*16-camera.y)>96||std::abs(key[2]*16-camera.z)>96)continue;
                    uniform3("origin",key[0]*16,key[1]*16,key[2]*16);BufferData(0x8892,s.vertices.size()*32,s.vertices.data(),0x88E0);glDrawArrays(GL_TRIANGLES,0,s.vertices.size());}
                if(!avatarBatches.empty()&&!avatarVertices.empty()){
                    double feetX=read<double>(0x110),feetY=read<double>(0x118),feetZ=read<double>(0x120);
                    if(!std::isfinite(feetX)||!std::isfinite(feetY)||!std::isfinite(feetZ)||(feetX==0&&feetY==0&&feetZ==0)){
                        feetX=camera.x;feetY=camera.y-1.55;feetZ=camera.z;
                    }
                    uniform3("origin",float(feetX),float(feetY),float(feetZ));
                    if(!avatarVbo)GenBuffers(1,&avatarVbo);
                    BindBuffer(0x8892,avatarVbo);
                    // VAO attributes remember the buffer bound when configured;
                    // rebinding ARRAY_BUFFER alone leaves them on the terrain VBO.
                    VertexAttribPointer(0,3,GL_FLOAT,0,32,nullptr);
                    VertexAttribPointer(1,2,GL_FLOAT,0,32,reinterpret_cast<void*>(12));
                    VertexAttribPointer(2,4,GL_UNSIGNED_BYTE,1,32,reinterpret_cast<void*>(20));
                    BufferData(0x8892,avatarVertices.size()*sizeof(p::RenVertex),avatarVertices.data(),0x88E0);
                    for(const auto &b:avatarBatches){
                        GLuint tex=atlas;
                        if(b.texture!=0){
                            auto it=entityTextures.find(b.texture);
                            if(it!=entityTextures.end()&&it->second.handle)tex=it->second.handle;
                        }
                        glBindTexture(GL_TEXTURE_2D,tex);
                        glDrawArrays(GL_TRIANGLES,b.first,b.count);
                    }
                }
            }
        }
        auto state=reinterpret_cast<volatile LONG*>(shared+p::kOffOverlayCtl);
        if(*state&4){front=InterlockedExchange(state,front)&3;if(front<3){auto hdr=reinterpret_cast<p::OverlaySlotHdr*>(shared+p::kOffOverlaySlotHdr+front*0x40);
            if(hdr->width&&hdr->height&&hdr->width<=p::kMaxOverlayW&&hdr->height<=p::kMaxOverlayH){
                // Scale is handled in the effect; allocate overlay at BOTW viewport for this slice.
                if(hdr->width==width&&hdr->height==height){subresource_data data{shared+p::kOffOverlayPixels+front*p::kOverlaySlotBytes,width*4,width*height*4};
                    rt->get_device()->update_texture_region(data,overlay.tex,0);overlayReady=true;}
                auto flip=findUniform(rt,"HyruleCraft.fx","OverlayBottomUp");if(flip.handle)rt->set_uniform_value_bool(flip,(hdr->flags&1)!=0);
            }}}
        // Wait for terrain, initial teleport acknowledgement, camera and a current
        // HUD upload. Once revealed, ordinary collision streaming never hides it.
        const bool cameraReady=!(a&1)&&a==read<uint32_t>(0xc00)&&camera.magic==0x41434348&&camera.projectionValid==1;
        const bool startupReady=cameraReady&&overlayReady&&(read<uint32_t>(0x204)&(1u<<8))&&read<uint32_t>(0x230)==read<uint32_t>(0x130);
        const bool presented=presentationGate.update(GetTickCount64(),startupReady);
        if(presented&&!presentationNoted){note("HyruleCraft: startup presentation ready after terrain, teleport, camera and HUD stabilization");presentationNoted=true;}
        avatarReady=presented?avatarReady:0;memcpy(shared+0xc74,&avatarReady,4);
        if(active.handle)rt->set_uniform_value_bool(active,presented);++frames;
        if(frames%120==0){bool available=false;auto dv=findUniform(rt,"HyruleCraft.fx","DepthAvailable");if(dv.handle)rt->get_uniform_value_bool(dv,&available,1);
            uint32_t ready=available?1:0;memcpy(shared+0xc4c,&ready,4);
            char s[300];snprintf(s,sizeof s,"HyruleCraft: frames=%llu messages=%llu sections=%zu avatar=%zu batches=%zu textures=%zu viewport=%ux%u depth=%s",(unsigned long long)frames,(unsigned long long)messages,sections.size(),avatarVertices.size(),avatarBatches.size(),entityTextures.size(),w,h,available?"available":"unavailable");note(s);}
    }
    BindFramebuffer(0x8CA9,oldFbo);BindFramebuffer(0x8CA8,oldReadFbo);UseProgram(oldProgram);BindVertexArray(oldVao);BindBuffer(0x8892,oldBuffer);
    glBindTexture(GL_TEXTURE_2D,oldTexture);ActiveTexture(oldActive);glViewport(oldViewport[0],oldViewport[1],oldViewport[2],oldViewport[3]);
    glPixelStorei(GL_UNPACK_ALIGNMENT,oldUnpack);glPixelStorei(GL_UNPACK_ROW_LENGTH,oldUnpackRow);glDepthFunc(oldDepthFunc);glDepthMask(oldMask);glColorMask(colorMask[0],colorMask[1],colorMask[2],colorMask[3]);
    auto restore=[](GLenum state,GLboolean on){if(on)glEnable(state);else glDisable(state);};
    restore(GL_DEPTH_TEST,oldDepth);restore(GL_BLEND,oldBlend);restore(GL_CULL_FACE,oldCull);restore(GL_SCISSOR_TEST,oldScissor);restore(0x8DB9,oldSRGB);
    ClipControl(oldOrigin,oldClip);
}
}
extern "C" __declspec(dllexport) const char *NAME="HyruleCraft";
extern "C" __declspec(dllexport) const char *DESCRIPTION="Real Minecraft mesh, hand and inventory rendering for isolated BOTW/Cemu OpenGL.";
BOOL APIENTRY DllMain(HMODULE module,DWORD reason,LPVOID) {
    if(reason==DLL_PROCESS_ATTACH){if(!reshade::register_addon(module))return FALSE;
        reshade::register_event<reshade::addon_event::reshade_begin_effects>(begin);
        reshade::register_event<reshade::addon_event::init_resource>(nativeResource);
        reshade::register_event<reshade::addon_event::destroy_effect_runtime>(release);}
    else if(reason==DLL_PROCESS_DETACH){restoreCursorWindow();reshade::unregister_addon(module);if(shared)UnmapViewOfFile(shared);if(mapping)CloseHandle(mapping);}
    return TRUE;
}


